<div class="input-group input-group-sm">
    <span class="input-group-addon"><strong><?php echo e($label); ?></strong></span>
    <?php echo $__env->make('admin::filter.' . $field->name(), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>