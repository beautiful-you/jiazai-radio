<html>
<body>
<form action="excelaction" method="get">
    开始日期&nbsp;&nbsp;<input type="date" name="start" placeholder="格式：20180101"><br>
    结束日期&nbsp;&nbsp;<input type="date" name="end" placeholder="格式：20180103"><br>
    <input type="submit" value="导出Excel"><br>
</form>
</body>
</html>